/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wedoeventsclient;

import entity.Customer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fowar
 */
public class WeDoEventsClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Integer port=9191;
        String host="127.0.0.1";
        BufferedReader in=null;
        PrintWriter out=null;
        try {
            InetAddress addr=InetAddress.getByName(host);
            Socket socket=new Socket(addr, port);
            in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
            int op=getOption();
            while(op!=0)
            {
                if(op==1)
                {
                    out.println(op+"#"+getCustomer().toString());
                    String data=in.readLine();
                    System.out.println(data);
                }
                else if(op==2)
                {
                    Scanner kb=new Scanner(System.in);
                    System.out.print("Enter Cell Number: ");
                    int cellNumber=kb.nextInt();
                    out.println(op+"#"+cellNumber);
                    String data=in.readLine();
                    System.out.println(data);   
                }
                else
                {
                    System.out.println("Wrong option");
                }
                op=getOption();
            }
        } catch (UnknownHostException ex) {
            System.err.println(ex.getMessage());
        } catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        
    }
    public static Customer getCustomer()
    {
        Scanner kb=new Scanner(System.in);
        System.out.print("Enter Cell Number: ");
        int cellNumber=kb.nextInt();
        
        System.out.print("Enter Number of Tickets: ");
        int numTick=kb.nextInt();
        
        System.out.print("Enter amount: ");
        double amount=kb.nextDouble();
        return new Customer(cellNumber, numTick, amount);
     }
    public static int getOption()
    {
        Scanner kb=new Scanner(System.in);
        System.out.print("Enter an Option\n"
                + "1. Add Customer\n"
                + "2. Delete Customer\n"
                + "0. exit\n"
                + "OPTION: ");
        return kb.nextInt(); 
    }
}
