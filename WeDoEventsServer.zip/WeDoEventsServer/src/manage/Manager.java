/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manage;

import entity.Customer;
import interf.WeDoEventsInterface;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Fowar
 */
public class Manager implements WeDoEventsInterface<Customer>{
    private Connection connection;
    public Manager() {
        try {
            connection=getConnection("jdbc:derby://localhost:1527/EventDB", "app", "123");
            
        } catch (SQLException ex) {
            System.err.println(ex.getMessage());
        }
    }


    @Override
    public boolean add(Customer c) throws SQLException {
    String sql="INSERT INTO EVENTTBL "
            + "VALUES(?,?,?,?)";
        PreparedStatement ps=connection.prepareStatement(sql);
        ps.setInt(1, c.getCellNumber());
        ps.setInt(2, c.getNumberTick());
        ps.setDouble(3, c.getAmount());
        ps.setTimestamp(4, c.getTime());
        ps.executeUpdate();
        ps.close();
        return true;
    }

    @Override
    public boolean delete(Integer id) throws SQLException {
    String sql="DELETE FROM EVENTTBL "
            + "WHERE CELLNUMBER=? ";
    PreparedStatement ps=connection.prepareStatement(sql);
    ps.setInt(1, id);
    ps.executeUpdate();
    ps.close();
    return true;
    }
    private Connection getConnection(String URL,String userName,String password) throws SQLException
    {
      return DriverManager.getConnection(URL, userName, password);  
    }
}
