/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wedoeventsserver;

import entity.Customer;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;
import thread.WeDoEventsThread;

/**
 *
 * @author Fowar
 */
public class WeDoEventsServer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Integer initial=100;
        ExecutorService pool=Executors.newFixedThreadPool(5);
        //WeDoEventsThread myThread=new WeDoEventsThread();//Set default initial number of tickets
        ArrayList<WeDoEventsThread> clients=new ArrayList<>();
        try {
            System.out.println("Waiting for connection!!");
            ServerSocket s=new ServerSocket(9191);
            
            while(true)
            { 
            Socket socket=s.accept();
            WeDoEventsThread myThread=new WeDoEventsThread(socket,WeDoEventsThread.initial);
            System.out.println("New connection established!!");
            Thread th=new Thread(myThread);
            clients.add(myThread);
            th.start();
            //pool.execute(myThread);
            }
            
        } 
        
        catch (IOException ex) {
            System.err.println(ex.getMessage());
        }
        System.out.println("Server closing!!");
    }
    
}
