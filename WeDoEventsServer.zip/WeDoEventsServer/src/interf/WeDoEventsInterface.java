
package interf;

import java.sql.SQLException;

public interface WeDoEventsInterface<C>{
  public boolean add(C c) throws SQLException;
  public boolean delete(Integer id) throws SQLException;
}
