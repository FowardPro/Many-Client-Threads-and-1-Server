/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thread;

import entity.Customer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import manage.Manager;

/**
 *
 * @author Fowar
 */
public class WeDoEventsThread implements Runnable{
private Socket socket;
private BufferedReader in=null;
private PrintWriter out=null;
public static Integer initial=100;

    public WeDoEventsThread() {
        initial=100; 
    }

    public WeDoEventsThread(Socket socket,Integer inialTickets) {
        this.socket = socket;
        initial=inialTickets;
    }

    public Integer getInitial() {
        return initial;
    }

    public void setInitial(Integer initail) {
        this.initial = initail;
    }
    
    @Override
    public void run() {
        
            Manager manage=new Manager();
    try {
        int count=1;
        while(true)
            { 
            in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
        
        out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
         System.out.print("Server$>On action "+count+": ");
        String data=in.readLine();
        String[] dataArray=data.split("#");
        
        if(dataArray[0].equals("1"))
        {
            int cellNumber=Integer.parseInt(dataArray[1]);
            int numTick=Integer.parseInt(dataArray[2]);
            double amount=Double.parseDouble(dataArray[3]);
            if(numTick<=initial)
            {
            Customer custom=new Customer(cellNumber, numTick, amount);
            updateInitialTickets(numTick);
            try {
                manage.add(custom);
                out.println("Customer added!!!");
            } catch (SQLException ex) {
                Logger.getLogger(WeDoEventsThread.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
            else
            {
               out.println("tickets sold out!!!"); 
            }
        }
        else if(dataArray[0].equals("2"))
        {
            int cellNumber=Integer.parseInt(dataArray[1]);
            manage=new Manager();
            try {
                manage.delete(cellNumber);
                out.println("Customer deleted!!!");
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }
        }
        else
        {
         out.println("Invalid option");
        }
        count++;
        System.out.println("Done!");
            }
    } catch (IOException ex) {
        System.err.println("One or all clients disconnected!!");
    }
        
    }
public synchronized void updateInitialTickets(Integer numberOfTickets)
{
    
    setInitial(initial-numberOfTickets);
    
}
}
